package yp.com.WebPages;

import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.LogStatus;

public class TimeSheet extends BaseTest {
	WebDriver driver;

	public TimeSheet(WebDriver driver) {
		this.driver = driver;
	}

	By Admin_username = By.cssSelector(or.getProperty("Username_CSS"));
	By Admin_password = By.cssSelector(or.getProperty("Password_CSS"));
	By empName = By.xpath(or.getProperty("EmpName_XPATH"));
	By project_textbox = By.xpath(or.getProperty("Project_XPATH"));
	By Activity_textbox = By.xpath(or.getProperty("Activty_XPATH"));
	By textbox_time = By.xpath(or.getProperty("TimeSheet_Text_XPATH"));
	By ceatetimeSheet = By.xpath(or.getProperty("CreateTimesheet_XPATH"));

	public void ApplyTimeSHeet(String UserName, String ProjectName) {
		ImplicitlyWait(10);
		ClickMethod("Time_Linktext");
		log.debug("Navigated to Time");
		ClickMethod("TimeSheet_Dropdown_XPATH");
		ClickMethod("EmpTimeSheet_Linktext");
		SendKeysMethod(empName, UserName);
		log.debug("Username " + UserName + "entered");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
		}
		WebElement EmplSelect = driver.findElement(empName);
		EmplSelect.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		ClickMethod("View_btn_CSS");
		try {
			WebElement createsheet = driver.findElement(ceatetimeSheet);
			if (createsheet.isDisplayed()) {
				ClickMethod("CreateTimesheet_XPATH");
				ClickMethod("Edit_btn_XPATH");
				SendKeysMethod(project_textbox, ProjectName);
				log.debug("Project name " + ProjectName + "selected");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
				}
				WebElement Project_DP = driver.findElement(project_textbox);
				Project_DP.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
				ClickMethod("Activty_XPATH");
				ClickMethod("activity_XPATH");
				List<WebElement> TimeText = driver.findElements(textbox_time);
				for (int i = 1; i <= 7; i++) {
					WebElement textbox = TimeText.get(i);
					textbox.sendKeys("9");
				}
				screenshot(driver, "Timesheet");
				log.debug("Timesheet filled");
				ClickMethod("Save_btn_CSS");

			}

		} catch (NoSuchElementException e) {
			test.log(LogStatus.FAIL, "TimeSheet Already Exists");
		}

	}
}
