package yp.com.WebPages;

import org.openqa.selenium.WebDriver;

public class Suprise extends BaseTest {

	WebDriver driver;

	public Suprise(WebDriver driver) {
		this.driver = driver;
	}

	public static void surprise() {
		
	}
	
	public static void main(String[] args) {
		surprise();
	}

}
