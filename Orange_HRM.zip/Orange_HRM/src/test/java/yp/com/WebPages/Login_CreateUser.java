package yp.com.WebPages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;
import yp.com.TestCases.DriverSetup;

public class Login_CreateUser extends BaseTest {

	WebDriver driver;

	public Login_CreateUser(WebDriver driver) {
		this.driver = driver;
	}


	By Admin_username = By.cssSelector(or.getProperty("Username_CSS"));
	By Admin_password = By.cssSelector(or.getProperty("Password_CSS"));
	By Usermanagement_deopdown_wait = By.xpath(or.getProperty("UserManagement_btn_XPATH"));
	By user_Role = By.xpath(or.getProperty("User_role_XPATH"));
	By Status = By.xpath(or.getProperty("Status_btn_XPATH"));
	By ProfileName_tab = By.xpath(or.getProperty("ProfileName_XPATH"));
	By EmpName = By.xpath(or.getProperty("EmployeeName_XPATH"));
	By username = By.xpath(or.getProperty("UserName_XPATH"));
	By UserExistError = By.xpath(or.getProperty("UserExist_Error_XPATH"));
	By password = By.xpath(or.getProperty("Password_XPATH"));
	By confirm_PW = By.xpath(or.getProperty("Confirm_PW_XPATH"));
	By userSearch = By.xpath(or.getProperty("UserName_Textbox_XPATH"));
	By filtered_User = By.xpath(or.getProperty("UserName_Feild_XPATH"));
	By WaitFor_RecordsFound = By.xpath(or.getProperty("RecordsFound_P_XPATH"));
	By WaiFor_LogoutBtn = By.linkText(or.getProperty("Logout_Linktext"));

	public void Entercredentials(String UserName, String Password) {
		SendKeysMethod(Admin_username, UserName);
		SendKeysMethod(Admin_password, Password);
		screenshot(driver, "LoginCredentials");
		ClickMethod("Login_btn_CSS");
		log.debug("Login Successful");
	}

	public void CreateUserForm(String NewUserName, String NewPassword) {
		ClickMethod("Admin_btn_Linktext");
		explicitWaitofElementClickable(20, Usermanagement_deopdown_wait);
		ClickMethod("UserManagement_btn_XPATH");
		ClickMethod("User_btn_Linktext");
		ClickMethod("+Add_btn_CSS");
		ImplicitlyWait(10);
		ClickMethod("User_role_XPATH");
		ImplicitlyWait(10);
		WebElement UserRole_dropdown = driver.findElement(user_Role);
		UserRole_dropdown.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		ClickMethod("Status_btn_XPATH");
		ImplicitlyWait(10);
		WebElement Status_dropdown = driver.findElement(Status);
		Status_dropdown.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		String p_name = driver.findElement(ProfileName_tab).getText();
		SendKeysMethod(EmpName, p_name);
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
		}
		WebElement EmpName_Textbox = driver.findElement(EmpName);
		EmpName_Textbox.sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
		SendKeysMethod(username, NewUserName);

		WebElement errorText = driver.findElement(UserExistError);
		if (errorText.getText().equals("Already exists")) {
			System.out.println("User already exist");
		} else {
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}
			if (NewUserName.length() > 5) {
				System.out.println("Entered name is valid");
				DriverSetup.test.log(LogStatus.INFO, "UserName is valid");
			} else {
				Assert.fail();
				DriverSetup.test.log(LogStatus.INFO, "Entered a Invalid UserName");
			}
			SendKeysMethod(password, NewPassword);
			log.debug("password entered");
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}
			SendKeysMethod(confirm_PW, NewPassword);
			log.debug("Confirm p entered");
			screenshot(driver, "New_User_Form");
			ClickMethod("Save_btn_CSS");
			log.debug("User Added Successfully");
		}
	}

	public void SearchNewUser(String NewUserName) {
		explicitWaitofElementvisibility(20, WaitFor_RecordsFound);
		SendKeysMethod(userSearch, NewUserName);
		ClickMethod("Search_btn_CSS");
		WebElement FilteredUser = driver.findElement(filtered_User);
		String UserName_String = FilteredUser.getText();
		Assert.assertTrue("User added in records", UserName_String.equals(NewUserName));
		System.out.println("New user Created Successfully");
		log.debug(" New User Validation Successful");
	}

	public void UserLogout() {
		ClickMethod("Profile_Tab_XPATH");
		explicitWaitofElementClickable(10, WaiFor_LogoutBtn);
		ClickMethod("Logout_Linktext");
		log.debug("Logged out Successfully");
	}
}
