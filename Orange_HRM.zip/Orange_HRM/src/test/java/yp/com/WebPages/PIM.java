package yp.com.WebPages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PIM extends BaseTest {

	WebDriver driver;

	public PIM(WebDriver driver) {
		this.driver = driver;
	}
	
	By Admin_username = By.cssSelector(or.getProperty("Username_CSS"));
	By Admin_password = By.cssSelector(or.getProperty("Password_CSS"));
	By firstname = By.cssSelector(or.getProperty("Emp_FirstName_CSS"));
	By middlename = By.cssSelector(or.getProperty("Emp_MiddleName_CSS"));
	By lastname = By.cssSelector(or.getProperty("Emp_LastName_CSS"));
	By Nickname = By.xpath(or.getProperty("Emp_nickName_XPATH"));
	By nationality_dropdown = By.xpath(or.getProperty("Nationality_XPATH"));
	By emp_imformation = By.xpath(or.getProperty("EmpImformation_XPATH"));
	
	public void AddEmployee(String FristName, String MiddleName, String Lastname, String NickName, String Countryname, String marital, String BirthMonth, String Birthyear) {
		ImplicitlyWait(10);
		ClickMethod("PIM_tab_Linktext");
		log.debug("Navigated to PIM");
		ClickMethod("+Add_btn_CSS");
		SendKeysMethod(firstname, FristName);
		SendKeysMethod(middlename, MiddleName);
		SendKeysMethod(lastname, Lastname);
		ClickMethod("Save_btn_CSS");
		
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
		}
		SendKeysMethod(Nickname, NickName);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,100)");
		ClickMethod("Nationality_XPATH");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
		}
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='oxd-select-option']"));
		try {
			for (WebElement country : list) {
				if (country.getText().equals(Countryname)) {
					country.click();
				}
			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Country got Selected");
		}
		log.debug("Country of " + Countryname + "got selected" );
		ClickMethod("MaritalStatus_XPATH");
		List<WebElement> Maritalstatus = driver.findElements(By.xpath("//div[@class='oxd-select-option']"));
		try {
			for (WebElement status : Maritalstatus) {
				if (status.getText().equals(marital)) {
					status.click();
				}
			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element got Selected");
		}
		log.debug("Marital status of " + marital + "got selected" );
		ClickMethod("Calander_DOB_XPATH");
		ClickMethod("Calander_Month_XPATH");
		List<WebElement> Month = driver.findElements(By.xpath(or.getProperty("Calander_Month_Value_XPATH")));
		for (WebElement month : Month) {
			if (month.getText().equals(BirthMonth)) {
				month.click();
			}
		}
		log.debug("BirthMonth of " + BirthMonth + "got selected" );
		ClickMethod("Calander_Year_XPATH");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
		}
		ClickMethod("Calander_Year_Value_XPATH");
		ClickMethod("Calendar_Day_XPATH");
		log.debug("Date selected" );
		js.executeScript("window.scrollBy(0,-200)");
		ClickMethod("Female_Radio_btn_XPATH");
		log.debug("Female radio button selected" );
		screenshot(driver, "PIM_userDetails");
		ClickMethod("Save_btn_CSS");
		log.debug("User created" );
	}
	
	public void SearchEmployee(String SearchUser) {
		ImplicitlyWait(10);
		ClickMethod("PIM_tab_Linktext");
		ClickMethod("Employee_List_Linktext");
		SendKeysMethod(emp_imformation, SearchUser);
		ClickMethod("Search_btn_CSS");
		ClickMethod("Reset_btn_CSS");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
		}
		ClickMethod("SecondUser_Checkbox_XPATH");
		log.debug("Checkbox checked");
		ClickMethod("DeleteSelected_btn_CSS");
		ClickMethod("Popup_Delete_CSS");
		log.debug("Record deleted");
		ClickMethod("Reset_btn_CSS");
	}
}
