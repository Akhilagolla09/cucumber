package yp.com.TestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import yp.com.WebPages.BaseTest;
import yp.com.WebPages.TimeSheet;

public class TimeSheet_Test extends BaseTest{
	
	@Test(dataProvider = "Exceldata")
	public void Scenatio_5(String UserName, String ProjectName) {
		TimeSheet obj = new TimeSheet(driver);
		
		//Creating Timesheet for the user
		obj.ApplyTimeSHeet(UserName, ProjectName);
	}
	
	@DataProvider
	public Object[][] Exceldata() {

		String sheetname = "TimeSheet";
		int rows = excel.getRowCount(sheetname);
		int cols = excel.getColumnCount(sheetname);
		
		System.out.println("Rows: " + rows + ", Cols: " + cols);

		Object[][] data = new Object[rows - 1][cols];

		for (int rowNum = 2; rowNum <= rows; rowNum++) {

			for (int colNum = 0; colNum < cols; colNum++) {

				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
			}
		}

		return data;
	}

}
