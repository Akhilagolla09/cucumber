package yp.com.TestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import yp.com.WebPages.JobTitle_PayGrades;

public class JobTitles_PayGrades_Test extends DriverSetup {


	
	
	@Test(dataProvider = "Exceldata")
	public void Scenario_2(String NewUserName, String NewPassword, String Jobtitle, String GradeName, String EmploymentStatus, String JobCategories, String WorkShift ) {
		JobTitle_PayGrades obj = new JobTitle_PayGrades(driver);
		//1.Open Chrome Browser > Enter Url of the website > Enter Valid Username and Password created in scenario 1 > Click on Login Button .
		obj.Entercredentials(NewUserName, NewPassword);
		
	
		//Navigating to JobTitles and adding new JobTitle
		obj.SelectJobTitles(Jobtitle);
		
		//Adding new GradeName for the user
		obj.SelectpayGrades(GradeName);
		
		//Adding new EmpoloyeStatus for the user
		obj.SelectEmployeeStatus(EmploymentStatus);
		
		//Adding new Jobcatrgory for the user
		obj.Selctjobcategories(JobCategories);
		
		//Adding new WorkShifts for the user
		obj.SelectWorkShifts(WorkShift);
		
		//Deleting created Workshift
		obj.DeleteWorkShift();
	}


	@DataProvider
	public Object[][] Exceldata() {

		String sheetname = "Job";
		int rows = excel.getRowCount(sheetname);
		int cols = excel.getColumnCount(sheetname);
		
		System.out.println("Rows: " + rows + ", Cols: " + cols);

		Object[][] data = new Object[rows - 1][cols];

		for (int rowNum = 2; rowNum <= rows; rowNum++) {

			for (int colNum = 0; colNum < cols; colNum++) {

				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
			}
		}
		return data;
	}

}
