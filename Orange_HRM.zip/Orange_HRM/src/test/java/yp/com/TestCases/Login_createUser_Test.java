package yp.com.TestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import yp.com.WebPages.Login_CreateUser;

public class Login_createUser_Test extends DriverSetup {

	@Test(dataProvider = "Exceldata")
	public void Scenario_1(String UserName, String password , String NewUserName, String NewPassword) {

		Login_CreateUser obj = new Login_CreateUser(driver);
		//1.Open Chrome Browser > Enter Url of the website > Enter Valid Username and Password > Click on Login Button .
		obj.Entercredentials(UserName, password);
		
		//Creating new user with valid credentials
		obj.CreateUserForm(NewUserName, NewPassword);
		
		//Searching for new user with username
		obj.SearchNewUser(NewUserName);
		
		//Logging out
		obj.UserLogout();
	}

	@DataProvider
	public Object[][] Exceldata() {

		String sheetname = "LogIn_data";
		int rows = excel.getRowCount(sheetname);
		int cols = excel.getColumnCount(sheetname);
		
		System.out.println("Rows: " + rows + ", Cols: " + cols);

		Object[][] data = new Object[rows - 1][cols];

		for (int rowNum = 2; rowNum <= rows; rowNum++) {

			for (int colNum = 0; colNum < cols; colNum++) {

				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
			}
		}

		return data;
	}

}
