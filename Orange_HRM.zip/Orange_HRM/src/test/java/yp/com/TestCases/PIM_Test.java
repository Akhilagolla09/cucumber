package yp.com.TestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import yp.com.WebPages.PIM;

public class PIM_Test extends DriverSetup {
	
	@Test(dataProvider = "Exceldata")
	public void Scenario_3(String FristName, String MiddleName, String Lastname, String NickName, String Countryname, String marital, String BirthMonth, String Birthyear, String SearchUser) {
		PIM obj = new PIM(driver);
		
		//Adding new User for PIM with required feilds
		obj.AddEmployee(FristName, MiddleName, Lastname, NickName, Countryname, marital, BirthMonth, Birthyear);
		
		//Searching for created Employee
		obj.SearchEmployee(SearchUser);
	}
	
	@DataProvider
	public Object[][] Exceldata() {

		String sheetname = "PIM";
		int rows = excel.getRowCount(sheetname);
		int cols = excel.getColumnCount(sheetname);
		
		System.out.println("Rows: " + rows + ", Cols: " + cols);

		Object[][] data = new Object[rows - 1][cols];

		for (int rowNum = 2; rowNum <= rows; rowNum++) {

			for (int colNum = 0; colNum < cols; colNum++) {

				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
			}
		}

		return data;
	}

}
