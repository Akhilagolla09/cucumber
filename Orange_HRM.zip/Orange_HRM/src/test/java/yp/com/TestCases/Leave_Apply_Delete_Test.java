package yp.com.TestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import yp.com.WebPages.Leave_Apply_Delete;

public class Leave_Apply_Delete_Test extends DriverSetup {
	
	@Test(dataProvider = "Exceldata")
	public void Scenario4(String UserName) {
		Leave_Apply_Delete obj= new Leave_Apply_Delete(driver);
		
		//Apply leave Request for the user
		obj.Applyleave(UserName);
	}
	
	@DataProvider
	public Object[][] Exceldata() {

		String sheetname = "Apply_Leave";
		int rows = excel.getRowCount(sheetname);
		int cols = excel.getColumnCount(sheetname);
		
		System.out.println("Rows: " + rows + ", Cols: " + cols);

		Object[][] data = new Object[rows - 1][cols];

		for (int rowNum = 2; rowNum <= rows; rowNum++) {

			for (int colNum = 0; colNum < cols; colNum++) {

				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
			}
		}
		return data;
	}

}
