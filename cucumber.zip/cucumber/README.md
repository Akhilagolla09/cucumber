# dbb_appium

Project to store automated test code 
Software required for appium
Mandatory software
1.  java 
  Download and install jdk
min version: 1.8.0_221
set environment variable JAVA_HOME and JRE_HOME and path

example
JAVA_HOME= C:\Program Files\Java\jdk1.8.0_221
etc

2.  android sdk
 Download and install android sdk
version:latest
set ANDROID_HOME and path 

3.Appium
version:latest
Download appium desktop app

Non Mandatory Software
1.Android studio
Version: Latest
Purpose: To create emulator 

2.Appium studio
Version: latest
Purpose: To identify mobile element easily

3.Node.js
Version: latest

4.Git
version : latest
During installation select option to take ssh key from system
Purpose: for maintenance of code


Setting required for real device
Android device: 
a) Enable developer option
b) connect device and enable usb debugging mode