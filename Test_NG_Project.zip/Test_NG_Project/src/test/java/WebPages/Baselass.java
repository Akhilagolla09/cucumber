package WebPages;

import org.openqa.selenium.WebElement;

import Testcases.Driver;

public class Baselass extends Driver{

	
	public void clickMethod(WebElement element) {
		
		element.click();
	}
	
	
}
