package WebPages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.aventstack.extentreports.model.Report;

public class HomePage extends Baselass{
	
	WebDriver driver;

	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	
	
	By radiobtm = By.linkText("Apparel & Shoes");
	By voteBtn = By.xpath("//div[@class='product-grid']/div");
	By search = By.id("small-searchterms");
	
	public void clickingVote() throws InterruptedException {
		
		WebElement rBtn = driver.findElement(radiobtm);
		Thread.sleep(3000);
		
		clickMethod(rBtn);
		log.debug("Button is clicked");
		
		WebElement siz = driver.findElement(voteBtn);
		
		List<WebElement> lis = driver.findElements(voteBtn);
		String s = siz.getText();
		 int size = lis.size();
		 System.out.println(s);
		 log.debug("size is printed");
		 
		 System.out.println(size);
		 log.debug("text is printed");
	}
	
	
	public void sendkeys(String ItemName) {
		System.setProperty("org.uncommons.reportng.escape-output", "false");
		driver.findElement(search).sendKeys(ItemName);
		
		System.out.println(ItemName);
		Reporter.log("Item name entered");
		//Reporter.log("<a href = \"C:\\Users\\rodara\\OneDrive - Capgemini\\Pictures\\Screenshots\\sc.png\">Screenshot</a>");
		Reporter.log("<a href= \"C:\\Users\\rodara\\OneDrive - Capgemini\\Pictures\\Mock.PNG\">Screenshot</a>");
	}
	
	public void web() {
		//WebElement ele = driver.findElement(By.xpath("//div[@class='products']//child::button"));
		List<WebElement> list = driver.findElements(By.xpath("//div[@class='products']//child::button"));
		
		for(int i = 0;i<5;i++) {
			for (WebElement l : list) {
				l.click();
			}
		}	
	}
}
