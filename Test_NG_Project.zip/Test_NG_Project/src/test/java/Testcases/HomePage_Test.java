package Testcases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import WebPages.HomePage;

public class HomePage_Test extends Driver {

	@Test(dataProvider = "getData")
	public void Home_Method(String ItemName) throws InterruptedException {

		HomePage home = new HomePage(driver);
		home.sendkeys(ItemName);

	}

	@DataProvider
	public Object[][] getData() {

		String sheetname = "Data1";
		int rows = excel.getRowCount(sheetname);
		int cols = excel.getColumnCount(sheetname);

		Object[][] data = new Object[rows - 1][cols];//object [1][1]
								
		for (int rowNum = 2; rowNum <= rows; rowNum++) {

			for (int colNum = 0; colNum < cols; colNum++) {

				// data [0][0]
				data[rowNum - 2][colNum] = excel.getCellData(sheetname, colNum, rowNum);
			}
		}
		return data;
	}
}
