package Testcases;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import utilities.ExcelReader;
import utilities.ExtentManager;

public class Driver {

	public static WebDriver driver;

	public static Logger log = Logger.getLogger("devpinoyLogger");

	public static ExtentReports report = ExtentManager.getInstance();
	public static ExtentTest test;
	public static ExcelReader excel = new ExcelReader("C:\\Users\\rodara\\OneDrive - Capgemini\\Desktop\\Selenium_Work\\Test_NG_Project\\src\\test\\resources\\excel\\DataFile.xlsx");

	@BeforeClass

	public void browserSetup() {

		EdgeOptions options = new EdgeOptions();
		options.addArguments("incognito");
		driver = new EdgeDriver(options);
		
		String act = "https://demowebshop.tricentis.com/";
		System.setProperty("webdriver.edge.driver",
				"C:\\Users\\rodara\\OneDrive - Capgemini\\Desktop\\Selenium_Work\\Test_NG_Project\\msedgedriver.exe");
		log.debug("Edge browser is open");
		driver.get("https://demowebshop.tricentis.com/");
		log.debug("Url is open");

		// driver.get("https://www.tatacliq.com/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		String exp = driver.getCurrentUrl();
		Assert.assertEquals(act, exp);
		System.out.println("Url Validated");
		log.debug("Validation is succeddful");

	}

	@AfterClass
	public void closeBrowser() {

		if (driver != null) {
			driver.quit();
			log.debug("driver is closed");

		}
	}
}
