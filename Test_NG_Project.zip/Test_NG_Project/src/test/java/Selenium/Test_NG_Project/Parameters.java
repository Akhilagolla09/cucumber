package Selenium.Test_NG_Project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class Parameters {
	WebDriver driver;
	@org.testng.annotations.Parameters({"browser","url"})
	
	@Test
	public void browserSetup(String browser, String url) {
		
		
		
		System.out.println("the browser is: " + browser);
		
		if(browser.equals("edge")) {
			driver = new EdgeDriver();
			System.setProperty("webdriver.edge.driver", "C:\\Users\\rodara\\OneDrive - Capgemini\\Desktop\\Selenium_Work\\Test_NG_Project\\msedgedriver.exe");
		}
		
		driver.get(url);
	}

}
