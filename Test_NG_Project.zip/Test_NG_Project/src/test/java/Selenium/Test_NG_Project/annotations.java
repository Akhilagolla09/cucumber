package Selenium.Test_NG_Project;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class annotations {

	@BeforeSuite
	public void beforesuite() {
		System.out.println("test before suite");
	}
	
	@AfterSuite
	public void aftersuite() {
		System.out.println("test before suite");
	}
	@BeforeTest
	public void OpenDBconnection() {
		System.out.println("DB is connected");
	}
	@AfterTest
	public void closeDBconnection() {
		System.out.println("DB is closed");
	}
	@BeforeMethod
	public void Openbrowser() {
		System.out.println("Browser is opened");
	}
	
	@AfterMethod
	public void closebrowser() {
		System.out.println("browser is closed");
	}
	@Test(priority = 0)
	public void LoginStatus() {
		System.out.println("Login Successful");
	}
	
	@Test(priority = 1,enabled = false)
	public void TitleVerification() {
		System.out.println("Title validated");
	}
	
	@Test(priority = 2)
	public void SearchProduct() {
		System.out.println("product is searched");
	}

}
