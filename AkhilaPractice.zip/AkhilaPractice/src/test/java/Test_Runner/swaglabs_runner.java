package Test_Runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/Feature/swaglabs.feature" , glue = {"step_definition"} ,

plugin = {"pretty" , "junit:target/JunitReports/report.xml1",
		"json:target/JSONReports/report.json1",
		"html:target/HtmlReports/report.html"
})



public class swaglabs_runner {

}
