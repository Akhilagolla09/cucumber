package Page_Factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class demowebshop {

	@FindBy(xpath = "//a[@class='ico-login']")
	WebElement login;

	@FindBy(id = "Email")
	WebElement username;

	@FindBy(name = "Password")
	WebElement Password;

	@FindBy(xpath = "//input[@class='button-1 login-button']")
	WebElement loginn;

	WebDriver driver;

	public void demowebshop(WebDriver driver1) { // constructer - name is same as class name

		this.driver = driver1;
		PageFactory.initElements(driver, demowebshop.class);
	}

	public void Login() {
		login.click();
	}

	public void credentials() {
		username.sendKeys("abcxxyz@gmail.com");
	}
	
	public void credentials1(){
		Password.sendKeys("1234567");
	}
	
	public void clickLogin() {
		loginn.click();
	}

}
