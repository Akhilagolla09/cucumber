package PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class swaglabs_POM {

	WebDriver driver;
	
	public swaglabs_POM(WebDriver driver1) {
		
		this.driver = driver1;
	}
	
	By email = By.xpath("(//input[@class='form_input'])[1]");
	By Password = By.xpath("(//input[@class='form_input'])[2]");
	By click = By.xpath("//input[@type='submit']");
	
	
	public void Email(String username) {
		
		WebElement mail = driver.findElement(email);
		mail.sendKeys(username);
	}
	
	public void passW(String password) {
		
		driver.findElement(Password).sendKeys(password);
	}
	
	public void logclick() {
		
		driver.findElement(click).click();
	}
	
}
