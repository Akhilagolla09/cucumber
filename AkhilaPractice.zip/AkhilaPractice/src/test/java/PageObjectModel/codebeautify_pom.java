package PageObjectModel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class codebeautify_pom {

	WebDriver driver;

	public codebeautify_pom(WebDriver driver) {

		this.driver = driver;
	}

	By login = By.xpath("//a[@id='notloggedin']");
	By email = By.id("user-email");
	By passWord = By.xpath("//input[@type='password']");
	By click = By.linkText("Login");

	public void Functionality1() {

		WebElement Logi = driver.findElement(login);
		Logi.click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	public void userpass() {

		WebElement Mail = driver.findElement(email);
		Mail.sendKeys("akhilasai0209@gmail.com");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	
	public void userpass1() {

		WebElement Passw = driver.findElement(passWord);
		Passw.sendKeys("18701a0405");
	}

	
	public void Button() {
		
		WebElement btn = driver.findElement(click);
		btn.click();

		driver.close();
	}

	

}
