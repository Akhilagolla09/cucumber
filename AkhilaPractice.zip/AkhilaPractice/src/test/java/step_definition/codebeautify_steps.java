package step_definition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjectModel.codebeautify_pom;
import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class codebeautify_steps {

	WebDriver driver;

	codebeautify_pom credentials;

	@Given("open browser and enter website url")
	public void open_browser_and_enter_website_url() {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://codebeautify.org/");

		driver.manage().window().maximize();

		driver.manage().deleteAllCookies();
	}

	@When("I click on login button")
	public void i_click_on_login_button() {

		credentials = new codebeautify_pom(driver);

		credentials.Functionality1();

	}

	@And("enter username")
	public void enter_username() {

		credentials.userpass();

	}

	@And("enter password")
	public void enter_password() {

		credentials.userpass1();

	}

	@Then("I successfully navigate to homepage")
	public void i_successfully_navigate_to_homepage() {

		credentials.Button();
		System.out.println("homepage");
	}

}
