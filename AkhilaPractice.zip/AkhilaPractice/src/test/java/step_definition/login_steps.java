package step_definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;


public class login_steps {

	static WebDriver driver;
	
	@Given("user is on login page")
	public void user_is_on_login_page() {
		
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		
		driver.get("https://demowebshop.tricentis.com/login");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//a[@class='ico-login']")).click();
	   
	}

	@When("user enter username and password")
	public void user_enter_username_and_password() throws InterruptedException {
	    
		
		driver.findElement(By.id("Email")).sendKeys("abcxxyz@gmail.com");
		driver.findElement(By.name("Password")).sendKeys("1234567");
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//Thread.sleep(2000);
	}

	@And("clicks on login button")
	public void clicks_on_login_button() {
	    
		driver.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		
	}

	@Then("user navigated to homepage")
	public void user_navigated_to_homepage() {
	    
		System.out.println("user logged in successfully");
		driver.close();
	}

	
}
