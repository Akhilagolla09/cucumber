package step_definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class swaglabs_steps {

/*	
	WebDriver driver; 
	
	@Given("open chrome browser and navigates to swag labs demo website")
	public void open_chrome_browser_and_navigates_to_swag_labs_demo_website() {
	   
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();
		
		
	}
		

	@When("^user enter enter the valid (.*) and (.*)$")
	public void user_enter_enter_the_valid_standard_user_and_secret_sauce(String username, String password) {
	   
		driver.findElement(By.xpath("(//input[@class='form_input'])[1]")).sendKeys(username);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("(//input[@class='form_input'])[2]")).sendKeys(password);
	}

	@Then("click on login button")
	public void user_navigate_to_homepage() {
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
	}

*/
	
}
