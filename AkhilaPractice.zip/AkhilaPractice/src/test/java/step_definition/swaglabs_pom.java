package step_definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageObjectModel.swaglabs_POM;
import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class swaglabs_pom {

	WebDriver driver;

//	swaglabs_POM Login = new swaglabs_POM(driver);           // Creating object of POM 
	swaglabs_POM Login;

	@Given("open chrome browser and navigates to swag labs demo website")
	public void open_chrome_browser_and_navigates_to_swag_labs_demo_website() {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://www.saucedemo.com/v1/");
		driver.manage().window().maximize();

		System.out.println("swag labs login page is opened");

	}

	@When("^user enter enter the valid (.*) and (.*)$")
	public void user_enter_enter_the_valid_standard_user_and_secret_sauce(String username, String password) {

		Login = new swaglabs_POM(driver); // Creating object of POM

		Login.Email(username);

		Login.passW(password);

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	@Then("click on login button")
	public void user_navigate_to_homepage() {

		Login.logclick();

	}

}
